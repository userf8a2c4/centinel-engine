# Instrucciones de Verificación Offline — Centinel Engine
## Paquete de Observador Electoral

Este paquete fue generado automáticamente por Centinel Engine durante el proceso electoral.

## ¿Qué contiene este paquete?

- `report_es.pdf` — Informe de auditoría en español
- `report_en.pdf` — Audit report in English
- `snapshot.json` — Datos crudos del snapshot electoral
- `hash_chain.json` — Cadena de hashes SHA-256 de todas las capturas
- `merkle_root.txt` — Raíz Merkle de la cadena de hashes
- `VERIFICATION.md` — Este archivo
- `manifest.sha256` — SHA-256 de todos los archivos del paquete

## Cómo verificar la integridad de este paquete

### Paso 1: Verificar el manifiesto

```bash
sha256sum --check manifest.sha256
```

Todos los archivos deben reportar "OK". Si alguno falla, el paquete ha sido modificado.

### Paso 2: Verificar la cadena de hashes

Abrir `hash_chain.json` y verificar que:
1. El campo `merkle_root` coincide con el contenido de `merkle_root.txt`
2. Cada bloque `previous_hash` coincide con el `hash` del bloque anterior
3. Los timestamps son monotónicamente crecientes

### Paso 3: Verificar el ancla Bitcoin (OpenTimestamps)

Si el archivo `checkpoint.ots` está incluido:
```bash
# Instalar: pip install opentimestamps-client
ots verify checkpoint.ots
```

Esto confirma que el primer hash del día existía antes de que terminara el proceso electoral.

### Paso 4: Verificar los datos crudos

El archivo `snapshot.json` contiene los datos originales tal como fueron capturados
de los servidores del CNE. Cualquier ciudadano puede comparar estos datos con lo que
el CNE publicó oficialmente.

## ¿Qué significa si la verificación falla?

Si `sha256sum --check manifest.sha256` reporta fallos:
- El paquete fue modificado después de ser generado
- Esto no significa necesariamente fraude — puede ser un error de transmisión
- Comparar con el paquete original publicado en el panel: https://github.com/userf8a2c4/centinel-engine

Si la cadena de hashes tiene discontinuidades:
- Algunos snapshots no fueron capturados (puede ocurrir por problemas de red)
- O los datos del CNE cambiaron entre capturas — esto sí es relevante investigar

## Contacto

Para reportar irregularidades técnicas en este paquete, abrir un issue en:
https://github.com/userf8a2c4/centinel-engine/issues
